﻿namespace ClinicManagement.Api.Dtos.User
{
    public class UpdateUserStatusRequest
    {
        public bool IsActive { get; set; }
    }
}
