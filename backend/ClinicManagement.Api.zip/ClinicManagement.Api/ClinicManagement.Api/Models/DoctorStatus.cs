﻿namespace ClinicManagement.Api.Models
{
    public enum DoctorStatus
    {
        Active = 1,
        Inactive = 2,
        OnLeave = 3
    }
}
